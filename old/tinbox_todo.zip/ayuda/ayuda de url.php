http://www.jqueryrain.com/?VAAZCOTI
http://www.jqueryrain.com/?VCDkD0JA
http://andyvr.github.io/picEdit/
http://www.jqueryrain.com/?qqmrgkC8
http://www.jqueryrain.com/?_bAUpi8F
http://www.jqueryrain.com/?jKrB7Iva

http://codecanyon.net/item/html-5-upload-image-ratio-with-drag-and-drop/full_screen_preview/8712634?ref=jqueryrain

http://www.jqueryrain.com/?j2D4wPA1


arrastrar imagen en jquery
http://phppot.com/jquery/jquery-drag-and-drop-image-upload/




cropper
http://spmjs.io/package/cropper

https://fengyuanchen.github.io/cropper/v0.7.9/  (bootstrap)

https://github.com/fengyuanchen/cropper


////////////////////////
https://github.com/fengyuanchen/cropper/issues/325


https://codepo8.github.io/canvas-images-and-pixels/
https://developer.mozilla.org/en-US/docs/Web/API/Canvas_API/Tutorial/Pixel_manipulation_with_canvas
http://www.w3schools.com/tags/canvas_putimagedata.asp

http://www.html5canvastutorials.com/advanced/html5-canvas-get-image-data-tutorial/
http://www.desarrollolibre.net/blog/tema/102/html/como-obtener-por-separado-el-canal-rgb-de-una-imagen-con-html5#.VmsYYSArIVw




http://stackoverflow.com/questions/28538913/crop-an-image-displayed-in-a-canvas
http://dropshado.ws/post/1244700472/putimagedata-is-a-complete-jerk

