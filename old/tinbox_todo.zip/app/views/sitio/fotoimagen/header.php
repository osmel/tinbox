<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="es_MX">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title>Prueba</title>
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
    
	   <!--este es quien tiene los iconos -->
	     <?php  echo link_tag('css/fotoimagen/cropear/assets/css/font-awesome.min.css'); ?>
	     <?php  echo link_tag('css/fotoimagen/cropear/dist/cropper.css'); ?>
	     <?php  echo link_tag('css/fotoimagen/cropear/demo/css/main.css'); ?>


</head>
<body>
	 
<?php //$this->load->view( 'navbar' ); ?>
	<?php //$this->load->view( 'carrusel' ); ?>
