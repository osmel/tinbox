<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

<footer id="pie">


</footer>


    <!-- Jquery -->
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>js/jquery.form.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>js/spin.min.js"></script>

    <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">

    <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
    <!-- <link rel="stylesheet" href="/resources/demos/style.css"> -->



    <?php  echo link_tag('css/normalize.css');  ?>
    <?php // echo link_tag('css/screen.css');  ?>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>

	
    <!-- nuestro js principal 
      <script type="text/javascript" src="<?php echo base_url(); ?>js/mio.js"></script>
    -->
  
    

    <!--para conversion a base64.encode y base64.decode -->
    <script src="<?php echo base_url(); ?>js/base64/jquery.base64.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>js/base64/jquery.base64.min.js" type="text/javascript"></script>
    


    <!-- Mi estilo -->
    <?php  echo link_tag('css/estilo.css'); ?>

    <!-- Scripts croppear  -->
    <script src="<?php echo base_url(); ?>js/fotoimagen/cropear/dist/cropper.js" type="text/javascript"></script>
    
    <script src="<?php echo base_url(); ?>js/fotoimagen/main.js" type="text/javascript"></script>
  


<!-- 
    Arrastrar imagenes
       <script type="text/javascript" src="<?php echo base_url(); ?>js/dist/min/dropzone.min.js"></script>
       <script type="text/javascript" src="<?php echo base_url(); ?>js/dropzone.js"></script>
       <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>js/dist/min/basic.min.css">
-->


  <!-- Plugins dependiente para mostrar las fechas 
    <script src="js/fotoimagen/moment.js" type="text/javascript"></script>

    <script src="js/fotoimagen/estrategas.calendarioEventos.js" type="text/javascript"></script>
    <script src="js/fotoimagen/calendario.js" type="text/javascript"></script>
-->

    <script src="<?php echo base_url(); ?>js/fotoimagen/sistema.js" type="text/javascript"></script>



</body>
</html>




    
    
    
