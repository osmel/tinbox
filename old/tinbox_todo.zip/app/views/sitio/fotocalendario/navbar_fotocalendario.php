<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

    <nav class="menu">
         <h1>CREA TU CALENDARIO</h1>
        <ul>
            <li><a href="#">1-ELIGE TU DISEÑO Y TAMAÑO</a></li>    
            <li><a href="#">2-PERSONALIZA</a></li>
            <li><a href="#">3-REVISA Y COMPRA</a></li>
        </ul>
    </nav>