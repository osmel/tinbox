<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

    <nav class="menu">
         <h1>CONOCE LOS TAMAÑOS DE CALENDARIO</h1>
        <ul>
            <li><a href="#">Mini</a></li>        
            <li><a href="#">Escritorio</a></li>        
            <li><a href="#">CD</a></li>        
            <li><a href="#">Postal</a></li>        
            <li><a href="#">Organizador</a></li>        
            <li><a href="#">Póster</a></li>
        </ul>
        
        <div class="row">
		      <div class="col-md-6">
		      		<img src="http://placehold.it/200x340" style="border:1px solid;">
		      </div>
		      <div class="col-md-6">
		      		<h1>PÓSTER VERTICAL </h1>
		      		<p>
		      			13 páginas a color de 30 x 44cm <br/>
		      			Cartulina premium con colgador	<br/>
		      			para pared y arillo metálico.	<br/>
		      		</p>

		      		<h1>$335</h1>
		      </div>

		 </div>		

    </nav>
