<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php $this->load->view( 'header' ); ?>

<div class="container margenes">
	<div class="panel panel-primary">
		<div class="panel-heading">Inicio</div>
			<div class="container">	
			
			</div>
	</div>
</div>
<?php $this->load->view( 'footer' ); ?>