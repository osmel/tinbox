<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>


<?php $this->load->view( 'header');  ?>
<script type="text/javascript" src="<?php echo base_url(); ?>js/sistema.js"></script>
	<?php echo $table; ?>
<?php $this->load->view( 'footer');  ?> 	
	
