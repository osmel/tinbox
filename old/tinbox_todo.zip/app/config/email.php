<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

    $config['protocol'] = 'mail';
    $config['wordwrap'] = FALSE;
    $config['mailtype'] = 'html';
    $config['charset'] = 'utf-8';
    $config['crlf'] = "\r\n";
    $config['newline'] = "\r\n";

?>