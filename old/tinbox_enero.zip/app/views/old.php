     
        <!--
       <div id="barraroja">  
             
            <div id="caja_menu"> 
                
                <div id="todo_logo_menu"> 
                        <img style="display: block;" id="logo1" src="img/logo1.png">
                        <img style="display: none;" id="logo2" src="img/logo2.png">
                </div>

                
                    http://getbootstrap.com/components/#navbar 
                    http://www.w3schools.com/bootstrap/bootstrap_case_navigation.asp
                  
                <div class="todo_texto_menu">
                   
                    <a class="elem_menu">
                        SOPORTE <br>TECNICO
                    </a> 
                    <a class="elem_menu">
                        PREGUNTAS <br>FRECUENTES
                    </a>                     
                    <a class="elem_menu">
                        ACERCA DE <br>NOSOTROS
                    </a> 
                    <a class="elem_menu">
                        CONTACTANOS <br>
                    </a>                 

                    <div style="clear:both;">     </div>
                </div>

 --> 


                 <!--
                <div style="clear:both;">     </div>

            </div>         

       </div>      -->   