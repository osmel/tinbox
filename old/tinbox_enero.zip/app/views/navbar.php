<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

    <nav class="menu">
        <ul>
            <li><a href="#">Home</a></li>    
            <li><a href="#">Calendarios</a></li>
            <li><a href="#">Fotocalendarios</a></li>
            <li><a href="#">Libretas</a></li>
            <li><a href="#">Agendas</a></li>
            <li><a href="#">Contacto</a></li>
        </ul>
    </nav>
