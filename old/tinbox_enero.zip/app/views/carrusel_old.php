	<div class="slider1" >
			<div class="slide">
				<img src="img/carrusel/banner1.jpg">
				

					<div class="container"> 
						<div class="caja_carrusel"> 
							<div class="texto_carrusel"> 
								<div class="tituloCarruselGen">
									 <h2>PRUEBA GRANDE</h2>
								</div> 
								<div class="tituloCarrusel">
									<h4>PRUEBA MEDIANA MEDIANA</h4>
								</div> 
								<div class="textinterior_carrusel">
									Probando Probando Probando
								</div> 
							</div> 
							<div class="leermas">
								<a href="http://www.ibero.mx/admision-licenciaturas-paso-paso">
									<h2>LEER MÁS</h2>
								</a>
							</div> 
						</div> 
					</div>


			</div>
			<div class="slide">
				<img src="img/carrusel/banner1.jpg">


					<div class="container"> 
						<div class="caja_carrusel"> 
							<div class="texto_carrusel"> 
								<div class="tituloCarruselGen">
									 <h2>PRUEBA GRANDE</h2>
								</div> 
								<div class="tituloCarrusel">
									<h4>PRUEBA MEDIANA MEDIANA</h4>
								</div> 
								<div class="textinterior_carrusel">
									Probando Probando Probando
								</div> 
								</div> 
								<div class="leermas">
									<a href="http://www.ibero.mx/admision-licenciaturas-paso-paso">
										<h2>LEER MÁS</h2>
									</a>
								</div> 
						</div> 
					</div>

			</div>
		  
		</div>