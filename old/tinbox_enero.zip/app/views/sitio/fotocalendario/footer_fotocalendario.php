<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

<footer id="pie">
    <div class="row"> 
        <div class="col-md-3"> 
           <img src="http://placehold.it/150x40">
        </div>
        
        <div class="col-md-3"> 
          <h5>INFORMACIÓN </h5>
          <a href="#"> Sobre nosotros    </a><br/>
          <a href="#"> Políticas de pago   </a><br/>
          <a href="#"> Términos y condiciones   </a><br/>
          <a href="#"> Contacto    </a><br/>
        </div>
        
        <div class="col-md-3"> 
          <h5>NUESTROS PRODUCTOS</h5>
          <a href="#"> Calendarios   </a><br/>
          <a href="#"> Cuadernos  </a><br/>
          <a href="#"> Libretas   </a><br/>
          <a href="#"> Agendas    </a><br/>
        </div>
        
        <div class="col-md-3"> 
            <p> 
                Georgia 181, Nápoles, <br/>
                Benito Juárez,<br/>
                Ciudad de México, D.F., México<br/>
                Tel. 56586989
            </p> 
            
            <img src="http://placehold.it/22x22" class="ico"> 
            <img src="http://placehold.it/22x22" class="ico"> 
            
        </div>
    </div>     
    
    
    
    
    <div class="row"> 
        <hr/>            
            <div class="col-md-2"> Tinbox2016 </div>
            <div class="col-md-2 col-md-offset-8"> Realizado por: Estrategas Digitales</div>
            
    </div>         



</footer>


    <!-- Jquery -->
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>js/jquery.form.min.js"></script>
 
 
    <script type="text/javascript" src="<?php echo base_url(); ?>js/spin.min.js"></script>

<!--   
   <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">

  <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
  <link rel="stylesheet" href="/resources/demos/style.css"> 

  -->



    <?php  echo link_tag('css/normalize.css');  ?>
    <?php // echo link_tag('css/screen.css');  ?>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>

   
    

    <!--para conversion a base64.encode y base64.decode -->
    <script src="<?php echo base_url(); ?>js/base64/jquery.base64.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>js/base64/jquery.base64.min.js" type="text/javascript"></script>
    


    <!-- Mi estilo -->
    <?php  echo link_tag('css/fotocalendario/estilo.css'); ?>
  
 

      <!-- Estilo del calendario -->
    <link rel="stylesheet" href="css/fotocalendario/calendarioEventos.css">

    <!-- Plugins dependiente para mostrar las fechas -->
    <script src="js/fotocalendario/moment.js" type="text/javascript"></script>

    <script src="js/fotocalendario/estrategas.calendarioEventos.js" type="text/javascript"></script>
    <script src="js/fotocalendario/calendario.js" type="text/javascript"></script>
    <script src="js/fotocalendario/sistema.js" type="text/javascript"></script>


</body>
</html>




    
    
    
