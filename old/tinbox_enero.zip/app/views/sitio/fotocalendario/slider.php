<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
    
      <aside>
          <div class="row">  
                <div class="col-xs-12 col-md-12">
                      <h4 class="form-control-static">TUS CALENDARIOS</h4>
                          
                          <div class="row cuadro_slider" value="1">

                                <div class="col-sm-12 col-md-12">
                                   <button disabled  value="1" type="button" class="editar_slider btn btn-success btn-block ttip" title="este es el tooltip.">editar</button>
                                </div>                              

                                <div class="col-sm-12 col-md-12">
                                   <button value="1" type="button" class="eliminar_slider btn btn-danger btn-block ttip" title="este es el tooltip.">Eliminar</button>
                                </div>      1                        

                                
                   

                              <img src="http://placehold.it/150x150" style="border:1px solid;">
                          </div>
                          

                          
                          <div class="row">---- </div>
                          
                          <div class="row cuadro_slider" value="2">
                            
                              <div class="col-sm-12 col-md-12">
                                  <button disabled  value="2" type="button" class="editar_slider btn btn-success btn-block ttip" title="este es el tooltip.">editar</button>
                              </div>   

                                <div class="col-sm-12 col-md-12">
                                   <button value="2" type="button" class="eliminar_slider btn btn-danger btn-block ttip" title="este es el tooltip.">Eliminar</button>
                                </div>    2                         

                              <img src="http://placehold.it/150x150" style="border:1px solid;">
                          </div>  


                          <div class="row">---- </div>
                          <div class="row cuadro_slider" value="3">
                            
                              <div class="col-sm-12 col-md-12">
                                  <button disabled  value="3" type="button" class="editar_slider btn btn-success btn-block ttip" title="este es el tooltip.">editar</button>
                              </div>   

                                <div class="col-sm-12 col-md-12">
                                   <button value="3" type="button" class="eliminar_slider btn btn-danger btn-block ttip" title="este es el tooltip.">Eliminar</button>
                                </div>     3                         

                              <img src="http://placehold.it/150x150" style="border:1px solid;">
                          </div>       


                          <div class="row">---- </div>
                          <div class="row cuadro_slider" value="4">
                            
                              <div class="col-sm-12 col-md-12">
                                  <button disabled  value="4" type="button" class="editar_slider btn btn-success btn-block ttip" title="este es el tooltip.">editar</button>
                              </div>   

                                <div class="col-sm-12 col-md-12">
                                   <button value="4" type="button" class="eliminar_slider btn btn-danger btn-block ttip" title="este es el tooltip.">Eliminar</button>
                                </div>     4                         

                              <img src="http://placehold.it/150x150" style="border:1px solid;">
                          </div>     

                          <div class="row">---- </div>
                          <div class="row cuadro_slider" value="5">
                            
                              <div class="col-sm-12 col-md-12">
                                  <button disabled  value="5" type="button" class="editar_slider btn btn-success btn-block ttip" title="este es el tooltip.">editar</button>
                              </div>   

                                <div class="col-sm-12 col-md-12">
                                   <button value="5" type="button" class="eliminar_slider btn btn-danger btn-block ttip" title="este es el tooltip.">Eliminar</button>
                                </div>      5                        

                              <img src="http://placehold.it/150x150" style="border:1px solid;">
                          </div>                                                                        
                         
                  </div>  
            </div> 

      </aside>