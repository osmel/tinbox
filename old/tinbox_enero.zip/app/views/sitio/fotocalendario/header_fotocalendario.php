<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="es_MX">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title>Prueba</title>
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
    
</head>
<body>

 <header class="cabecera">
        <h1>Tinbox la cabecera</h1>
        <time datetime="2016-01-01" pubdate>publicado 01-01-2016</time>
    	<div id="foo"></div>
    	<div class="alert" id="messages"></div>
 </header>   

<?php $this->load->view( 'navbar' ); ?>
  <?php $this->load->view( 'carrusel' ); ?>
